Game name: ALIENS!!!!

Scenario: You are stranded in space aboard your mothership when all of a sudden... WOAH.  Aliens are approaching!  Your ship's weapons are out of ammunition from your last encounter with the aliens, so it looks like you'll have to escape them!  The hordes seem endless, and probably are, so survive as long as you can!

Goal: Dodge the aliens.

Controls: Press start to begin the game.  Use the up, down, left, and right keys to move your ship.  Press select at any time to return to the main menu.  Press select or start after the game is over to return to the main menu. 

Enjoy!