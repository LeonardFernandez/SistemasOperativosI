# xinu-x86-gui
Xinu OS for x86 with graphical vga, mouse and keyboard environment (gui)

